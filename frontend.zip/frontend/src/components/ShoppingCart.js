const ShoppingCart = () => {
    return(
        <h1>Shopping-Cart</h1>
    );
}

export default ShoppingCart;