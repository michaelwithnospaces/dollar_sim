const Parent = () => {
    return(
        <h1>Parent Page</h1>
    );
}

export default Parent