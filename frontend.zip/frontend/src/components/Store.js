const Store = () => {
    return(
        <h1>Store Page</h1>
    );
}

export default Store